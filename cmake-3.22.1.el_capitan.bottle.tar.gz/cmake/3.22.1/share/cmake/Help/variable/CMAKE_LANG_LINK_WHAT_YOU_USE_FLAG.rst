CMAKE_<LANG>_LINK_WHAT_YOU_USE_FLAG
-----------------------------------

.. versionadded:: 3.22

Linker flag to be used to configure linker so that all specified libraries on
the command line will be linked into the target.

See also variable :variable:`CMAKE_LINK_WHAT_YOU_USE_CHECK`.
