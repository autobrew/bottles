CMAKE_PATCH_VERSION
-------------------

Third version number component of the :variable:`CMAKE_VERSION`
variable.
