CMAKE_<LANG>_FLAGS_RELEASE
--------------------------

This variable is the ``Release`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>` variable.
