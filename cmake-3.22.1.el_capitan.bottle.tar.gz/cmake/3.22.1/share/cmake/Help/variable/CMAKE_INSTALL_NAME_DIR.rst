CMAKE_INSTALL_NAME_DIR
----------------------

Directory name for installed targets on Apple platforms.

``CMAKE_INSTALL_NAME_DIR`` is used to initialize the
:prop_tgt:`INSTALL_NAME_DIR` property on all targets.  See that target
property for more information.
