/**
 * Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * SPDX-License-Identifier: Apache-2.0.
 */


#pragma once

#define USE_PROXY_FOR_TESTS 0
#define PROXY_HOST "localhost"
#define PROXY_PORT 8080
