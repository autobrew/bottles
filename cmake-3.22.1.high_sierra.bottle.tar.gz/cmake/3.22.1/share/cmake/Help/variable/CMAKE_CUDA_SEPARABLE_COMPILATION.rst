CMAKE_CUDA_SEPARABLE_COMPILATION
--------------------------------

.. versionadded:: 3.11

Default value for :prop_tgt:`CUDA_SEPARABLE_COMPILATION` target property.
This variable is used to initialize the property on each target as it is
created.
