CMAKE_PCH_WARN_INVALID
----------------------

This variable is used to initialize the :prop_tgt:`PCH_WARN_INVALID`
property of targets when they are created.
