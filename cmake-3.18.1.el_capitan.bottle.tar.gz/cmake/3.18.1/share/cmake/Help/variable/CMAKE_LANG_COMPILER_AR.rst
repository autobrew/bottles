CMAKE_<LANG>_COMPILER_AR
------------------------

A wrapper around ``ar`` adding the appropriate ``--plugin`` option for the
compiler.

See also :variable:`CMAKE_AR`.
