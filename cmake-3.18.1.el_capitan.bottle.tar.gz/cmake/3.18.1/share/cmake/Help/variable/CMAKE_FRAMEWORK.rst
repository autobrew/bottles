CMAKE_FRAMEWORK
---------------

Default value for :prop_tgt:`FRAMEWORK` of targets.

This variable is used to initialize the :prop_tgt:`FRAMEWORK` property on
all the targets.  See that target property for additional information.
