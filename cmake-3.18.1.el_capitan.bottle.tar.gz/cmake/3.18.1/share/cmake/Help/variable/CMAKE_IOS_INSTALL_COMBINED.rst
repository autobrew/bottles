CMAKE_IOS_INSTALL_COMBINED
--------------------------

Default value for :prop_tgt:`IOS_INSTALL_COMBINED` of targets.

This variable is used to initialize the :prop_tgt:`IOS_INSTALL_COMBINED`
property on all the targets.  See that target property for additional
information.
